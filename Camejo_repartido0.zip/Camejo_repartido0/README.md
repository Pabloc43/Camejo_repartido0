# Camejo_repartido0

##Actividad 6:

La navegación en esta "Landing-Page" es a través de los botones superiores: "HOME", "ABOUT
", "WORKS
", "CONTACT
", llevando estos a secciones en orden decendente
 de nuestra página.

HOME: Parte de arriba donde se presenta la persona y se puede ver una foto.

ABOUT
: Presentación.

WORKS
: En esta sección se pueden ver trabajos de la persona.

CONTACT
: Sección para el contacto que es a su vez el pie de página.


##Actividad 7:

La interacción entre las tres pantallas seria
 a través de la barra de navegación: Dando en el botón de Home, Tienda, Cuenta, o el de Carrito si se quisiera entrar a alguna de estas pantallas respectivamente, algo a notar es que la cabecera y el pie de página se mantienen constantes.

Pantalla de Home: 
En esta pantalla se pueden ver productos disponibles, testimonios de personas, ademas de algunas marcas que están en tienda, también decir que si se da click en alguno de los productos se accedería a la parte de tienda, donde se mostraría el mismo destacado.

Pantalla Tienda:
En la pantalla de tienda se pueden buscar productos, luego seleccionar por categorías, escoger alguno si 
quieres, ver o eliminar los que están en el carrito.

Parte Producto:
Esta parte pertenece a la tienda, lo que aquí se puede ver un producto seleccionado en específico, si se quiere agregar, eliminar, ver la descripción, Ademas que se pueden ver otros productos similares en la parte posterior entre.

Parte Resumen de Compra:
Aquí se pueden ver los productos marcados como favoritos, cantidad total, eliminar, si se tiene algún cupón de descuento, forma de pago, otras recomendaciones entre otros. Esta pantalla seria para realizar la compra.
